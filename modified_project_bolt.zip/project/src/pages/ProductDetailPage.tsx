import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { products } from '../data/products';
import { Star, ShoppingCart, Heart, Share2, ArrowLeft, Check } from 'lucide-react';
import Button from '../components/ui/Button';
import ProductCard from '../components/product/ProductCard';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [showNotification, setShowNotification] = useState(false);
  
  // Find the product by ID
  const product = products.find(p => p.id === id);
  
  // Handle quantity change
  const handleQuantityChange = (value: number) => {
    if (value >= 1) {
      setQuantity(value);
    }
  };
  
  // Handle add to cart
  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart(product, quantity, selectedColor, selectedSize);
    
    // Show notification
    setShowNotification(true);
    setTimeout(() => setShowNotification(false), 3000);
  };
  
  // If product not found
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-32 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link to="/shop" className="text-blue-600 hover:text-blue-700 transition-colors">
          Return to Shop
        </Link>
      </div>
    );
  }
  
  // Find related products (same category)
  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  
  // Calculate discount price if any
  const discountedPrice = product.discount 
    ? product.price * (1 - product.discount / 100) 
    : null;
  
  return (
    <main className="pt-24 pb-16">
      {/* Notification */}
      {showNotification && (
        <div className="fixed top-20 right-4 z-50 bg-green-100 border-l-4 border-green-500 p-4 rounded shadow-lg flex items-center max-w-sm animate-slideIn">
          <Check className="text-green-500 mr-3" size={20} />
          <div>
            <h3 className="font-semibold text-green-800">Added to Cart!</h3>
            <p className="text-green-700 text-sm">{product.name} has been added to your cart.</p>
          </div>
        </div>
      )}
      
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <div className="mb-6">
          <nav className="flex items-center text-sm text-gray-500">
            <Link to="/" className="hover:text-blue-600 transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/shop" className="hover:text-blue-600 transition-colors">Shop</Link>
            <span className="mx-2">/</span>
            <Link to={`/category/₹{product.category.toLowerCase()}`} className="hover:text-blue-600 transition-colors">
              {product.category}
            </Link>
            <span className="mx-2">/</span>
            <span className="text-gray-900">{product.name}</span>
          </nav>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-12 mb-16">
          {/* Product Image */}
          <div className="lg:w-1/2">
            <div className="bg-gray-50 rounded-xl overflow-hidden">
              <img 
                src={product.imageUrl} 
                alt={product.name} 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
          
          {/* Product Info */}
          <div className="lg:w-1/2">
            {/* Back to Shop - Mobile only */}
            <Link 
              to="/shop" 
              className="inline-flex items-center text-sm text-gray-600 hover:text-blue-600 transition-colors mb-4 lg:hidden"
            >
              <ArrowLeft size={16} className="mr-1" />
              Back to Shop
            </Link>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
            
            {/* Rating */}
            <div className="flex items-center mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-5 h-5 ₹{i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                  />
                ))}
              </div>
              <span className="text-gray-600 ml-2">{product.rating} ({Math.floor(product.rating * 10)} reviews)</span>
            </div>
            
            {/* Price */}
            <div className="mb-6">
              {discountedPrice ? (
                <div className="flex items-center">
                  <span className="text-2xl font-bold text-gray-900">₹{discountedPrice.toFixed(2)}</span>
                  <span className="text-lg text-gray-500 line-through ml-3">₹{product.price.toFixed(2)}</span>
                  <span className="ml-3 bg-red-100 text-red-700 px-2 py-1 rounded text-sm font-medium">
                    {product.discount}% OFF
                  </span>
                </div>
              ) : (
                <span className="text-2xl font-bold text-gray-900">₹{product.price.toFixed(2)}</span>
              )}
            </div>
            
            {/* Description */}
            <div className="mb-8">
              <p className="text-gray-700 leading-relaxed">
                {product.description}
              </p>
            </div>
            
            {/* Color Selection */}
            {product.colors && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Color</h3>
                <div className="flex space-x-3">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`
                        w-10 h-10 rounded-full border-2 transition-all
                        ₹{selectedColor === color 
                          ? 'border-blue-600 ring-2 ring-blue-200' 
                          : 'border-gray-300 hover:border-gray-400'
                        }
                      `}
                      style={{ backgroundColor: color.toLowerCase() }}
                      aria-label={`Select ₹{color} color`}
                    />
                  ))}
                </div>
              </div>
            )}
            
            {/* Size Selection */}
            {product.sizes && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-medium text-gray-900">Size</h3>
                  <a href="#size-guide" className="text-sm text-blue-600 hover:text-blue-700 transition-colors">
                    Size Guide
                  </a>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`
                        py-2 border rounded-md text-sm font-medium transition-all
                        ₹{selectedSize === size 
                          ? 'bg-gray-900 text-white border-gray-900' 
                          : 'bg-white text-gray-900 border-gray-300 hover:bg-gray-50'
                        }
                      `}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Quantity Selector */}
            <div className="mb-8">
              <h3 className="text-sm font-medium text-gray-900 mb-3">Quantity</h3>
              <div className="flex items-center">
                <button
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  className="w-10 h-10 border border-gray-300 rounded-l-md flex items-center justify-center text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value))}
                  className="w-16 h-10 border-t border-b border-gray-300 text-center"
                />
                <button
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="w-10 h-10 border border-gray-300 rounded-r-md flex items-center justify-center text-gray-600 hover:bg-gray-50"
                >
                  +
                </button>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="flex-1"
                size="lg"
              >
                <ShoppingCart size={20} className="mr-2" />
                {product.inStock ? 'Add to Cart' : 'Out of Stock'}
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                size="lg"
              >
                <Heart size={20} className="mr-2" />
                Add to Wishlist
              </Button>
            </div>
            
            {/* Product Metadata */}
            <div className="border-t border-gray-200 pt-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-gray-500">Availability:</span>
                <span className={`text-sm font-medium ₹{product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
              </div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-gray-500">Category:</span>
                <Link to={`/category/₹{product.category.toLowerCase()}`} className="text-sm text-blue-600 hover:text-blue-700 transition-colors">
                  {product.category}
                </Link>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Share:</span>
                <div className="flex space-x-2">
                  <button className="p-2 text-gray-500 hover:text-blue-600 transition-colors">
                    <Share2 size={18} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Details Tabs */}
        <div className="mb-16">
          <div className="border-b border-gray-200 mb-8">
            <div className="flex space-x-8">
              <button className="border-b-2 border-blue-600 text-blue-600 py-4 px-1 font-medium">
                Description
              </button>
              <button className="text-gray-500 hover:text-gray-700 py-4 px-1">
                Additional Information
              </button>
              <button className="text-gray-500 hover:text-gray-700 py-4 px-1">
                Reviews ({Math.floor(product.rating * 10)})
              </button>
            </div>
          </div>
          
          <div className="prose prose-blue max-w-none">
            <h2 className="text-xl font-bold mb-4">Product Description</h2>
            <p className="mb-4">
              {product.description}
            </p>
            <p className="mb-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, velit vel ultricies malesuada, nunc dolor venenatis nisl, vel tincidunt nisl nunc vel nisi. Donec sit amet sem vitae leo tincidunt tincidunt.
            </p>
            <h3 className="text-lg font-semibold mb-2">Key Features</h3>
            <ul className="list-disc pl-5 mb-4">
              <li>Premium quality materials for long-lasting durability</li>
              <li>Thoughtfully designed for both form and function</li>
              <li>Sustainable manufacturing processes</li>
              <li>Backed by our customer satisfaction guarantee</li>
            </ul>
          </div>
        </div>
        
        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">You May Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

export default ProductDetailPage;