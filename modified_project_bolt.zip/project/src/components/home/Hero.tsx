import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <section className="pt-32 pb-16 md:py-32 lg:py-44 relative overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-50 to-indigo-50 z-0" />
      
      {/* Decorative circles */}
      <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-blue-200 opacity-20 blur-3xl" />
      <div className="absolute bottom-20 -left-20 w-80 h-80 rounded-full bg-indigo-200 opacity-20 blur-3xl" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="w-full lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-4">
              Discover Premium <span className="text-blue-600">Products</span> For Your Lifestyle
            </h1>
            <p className="text-lg text-gray-600 mb-8 max-w-lg">
              Curated selection of high-quality items to elevate your everyday experiences. Shop the latest trends with confidence.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                as={Link} 
                to="/shop" 
                size="lg"
                className="inline-flex items-center"
              >
                Shop Now
                <ArrowRight size={18} className="ml-2" />
              </Button>
              <Button 
                as={Link} 
                to="/category/featured" 
                variant="outline" 
                size="lg"
              >
                Explore Featured
              </Button>
            </div>
            
            {/* Metrics */}
            <div className="flex justify-start mt-12">
              <div className="mr-12">
                <p className="text-3xl font-bold text-gray-900">15k+</p>
                <p className="text-gray-600">Products</p>
              </div>
              <div className="mr-12">
                <p className="text-3xl font-bold text-gray-900">250+</p>
                <p className="text-gray-600">Brands</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-gray-900">98%</p>
                <p className="text-gray-600">Happy Customers</p>
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/2 relative">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-xl transform transition-all duration-500 hover:scale-[1.02]">
              <img 
                src="https://images.pexels.com/photos/1488463/pexels-photo-1488463.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Premium Products" 
                className="w-full h-auto"
              />
              
              {/* Overlay with product highlight */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <p className="text-white text-sm font-medium mb-1">Featured Collection</p>
                <h3 className="text-white text-xl font-bold mb-2">Premium Lifestyle Products</h3>
                <Link 
                  to="/category/featured" 
                  className="text-blue-300 hover:text-white transition-colors text-sm inline-flex items-center"
                >
                  View Collection
                  <ArrowRight size={14} className="ml-1" />
                </Link>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-blue-600 rounded-xl opacity-80 blur-sm" />
            <div className="absolute -top-6 -right-6 w-20 h-20 bg-yellow-400 rounded-full opacity-80 blur-sm" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;