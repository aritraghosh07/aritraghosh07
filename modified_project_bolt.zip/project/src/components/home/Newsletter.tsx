import React, { useState } from 'react';
import Button from '../ui/Button';
import { Loader2 } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Stripe integration will be added here
      setSuccess(true);
      setEmail('');
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-16 bg-blue-600 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-blue-500 opacity-30" />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full bg-blue-400 opacity-30" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Subscribe to Our Newsletter
          </h2>
          <p className="text-blue-100 mb-8 text-lg">
            Stay updated with our latest products, exclusive offers, and upcoming sales for just ₹1/month.
          </p>
          
          <form onSubmit={handleSubmit} className="max-w-xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address" 
                className="flex-grow px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-800"
                required
              />
              <Button
                variant="secondary"
                size="lg"
                className="whitespace-nowrap"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 size={20} className="animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  'Subscribe (₹1/month)'
                )}
              </Button>
            </div>

            {error && (
              <p className="text-red-200 text-sm mt-2">{error}</p>
            )}

            {success && (
              <p className="text-green-200 text-sm mt-2">
                Thank you for subscribing! Please check your email to complete the subscription.
              </p>
            )}
          </form>
          
          <p className="text-blue-200 text-sm mt-4">
            By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
            Your card will be charged ₹1 monthly for premium newsletter access.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;