import React from 'react';

// Testimonial data
const testimonials = [
  {
    id: 1,
    text: "The quality of products I received exceeded my expectations. The customer service was exceptional, and my order arrived faster than anticipated.",
    author: "Sarah Johnson",
    position: "Loyal Customer",
    avatar: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 2,
    text: "I've been shopping with LuxeMarket for over a year now, and I've never been disappointed. Their product selection is amazing, and the quality is always top-notch.",
    author: "Michael Chen",
    position: "Fashion Enthusiast",
    avatar: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  },
  {
    id: 3,
    text: "The attention to detail in packaging and product quality is impressive. LuxeMarket has become my go-to for premium products that last.",
    author: "Emily Rodriguez",
    position: "Interior Designer",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 text-center mb-4">What Our Customers Say</h2>
        <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">
          Don't just take our word for it — hear from our satisfied customers about their shopping experience.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              {/* Quote icon */}
              <div className="mb-4 text-blue-600">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19.9876 6.66675C12.0545 6.66675 5.82129 12.9 5.82129 20.8334C5.82129 28.7667 12.0545 35.0001 19.9876 35.0001C27.9207 35.0001 34.1539 28.7667 34.1539 20.8334C34.1539 12.9 27.9207 6.66675 19.9876 6.66675ZM15.8214 25.8334C15.8214 26.0584 15.6379 26.2501 15.4129 26.2501H13.7462C13.5212 26.2501 13.3296 26.0584 13.3296 25.8334V20.4167H12.9129C12.6879 20.4167 12.4962 20.2251 12.4962 20.0001V18.7501C12.4962 18.5251 12.6879 18.3334 12.9129 18.3334H15.4129C15.6379 18.3334 15.8214 18.5251 15.8214 18.7501V25.8334ZM26.6545 25.8334C26.6545 26.0584 26.4629 26.2501 26.2379 26.2501H24.5712C24.3462 26.2501 24.1545 26.0584 24.1545 25.8334V20.4167H23.7379C23.5129 20.4167 23.3212 20.2251 23.3212 20.0001V18.7501C23.3212 18.5251 23.5129 18.3334 23.7379 18.3334H26.2379C26.4629 18.3334 26.6545 18.5251 26.6545 18.7501V25.8334Z" fill="currentColor" />
                </svg>
              </div>
              
              <p className="text-gray-700 mb-6">{testimonial.text}</p>
              
              <div className="flex items-center">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.author} 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-bold text-gray-900">{testimonial.author}</h4>
                  <p className="text-gray-500 text-sm">{testimonial.position}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;