import React, { useState, useEffect } from 'react';
import { ShoppingCart, Heart, User, Menu, X, Search } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { categories } from '../../data/products';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { totalItems } = useCart();
  const location = useLocation();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ₹{
        isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-blue-600">
            LuxeMarket
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            <Link to="/" className="text-gray-800 hover:text-blue-600 transition-colors">
              Home
            </Link>
            {categories.slice(0, 4).map((category) => (
              <Link 
                key={category.id} 
                to={`/category/₹{category.slug}`}
                className="text-gray-800 hover:text-blue-600 transition-colors"
              >
                {category.name}
              </Link>
            ))}
            <Link to="/shop" className="text-gray-800 hover:text-blue-600 transition-colors">
              All Products
            </Link>
          </nav>

          {/* Search & Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                className="w-40 lg:w-60 h-10 pl-10 pr-4 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <Link to="/wishlist" className="relative p-2 text-gray-700 hover:text-blue-600 transition-colors">
              <Heart size={24} />
            </Link>
            <Link to="/cart" className="relative p-2 text-gray-700 hover:text-blue-600 transition-colors">
              <ShoppingCart size={24} />
              {totalItems > 0 && (
                <span className="absolute top-0 right-0 h-5 w-5 rounded-full bg-blue-600 text-white text-xs flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Link>
            <Link to="/account" className="p-2 text-gray-700 hover:text-blue-600 transition-colors">
              <User size={24} />
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md p-4 animate-slideDown">
            <div className="flex items-center mb-4">
              <input
                type="text"
                placeholder="Search products..."
                className="flex-1 h-10 pl-10 pr-4 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <Search className="absolute left-7 top-7 h-5 w-5 text-gray-400" />
            </div>
            
            <nav className="flex flex-col space-y-3">
              <Link to="/" className="text-gray-800 hover:text-blue-600 transition-colors py-2">
                Home
              </Link>
              {categories.map((category) => (
                <Link 
                  key={category.id} 
                  to={`/category/₹{category.slug}`}
                  className="text-gray-800 hover:text-blue-600 transition-colors py-2"
                >
                  {category.name}
                </Link>
              ))}
              <Link to="/shop" className="text-gray-800 hover:text-blue-600 transition-colors py-2">
                All Products
              </Link>
              <div className="h-px bg-gray-200 my-2"></div>
              <div className="flex justify-around">
                <Link to="/wishlist" className="flex items-center text-gray-700 hover:text-blue-600 transition-colors py-2">
                  <Heart size={20} className="mr-2" />
                  Wishlist
                </Link>
                <Link to="/cart" className="flex items-center text-gray-700 hover:text-blue-600 transition-colors py-2">
                  <ShoppingCart size={20} className="mr-2" />
                  Cart {totalItems > 0 && `(₹{totalItems})`}
                </Link>
                <Link to="/account" className="flex items-center text-gray-700 hover:text-blue-600 transition-colors py-2">
                  <User size={20} className="mr-2" />
                  Account
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;